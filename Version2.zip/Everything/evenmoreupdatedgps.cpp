#include <SoftwareSerial.h>
#include <TinyGPS++.h>
#include <SPI.h>
#include <RF24.h>

// GPS setup
#define GPS_RX 4  // GPS TX -> Arduino RX
#define GPS_TX 3  // GPS RX <- Arduino TX (via voltage divider)
SoftwareSerial gpsSerial(GPS_RX, GPS_TX);
TinyGPSPlus gps;

// NRF24L01 setup
#define CE_PIN 7
#define CSN_PIN 8
RF24 radio(CE_PIN, CSN_PIN);
const byte receiverAddress[6] = "05050";

unsigned long lastUpdate = 0;
const unsigned long updateInterval = 2000;

void setup() {
  Serial.begin(9600);
  gpsSerial.begin(9600);

  Serial.println(F("📡 GPS + NRF24L01 Transmitter Initialized"));
  Serial.println(F("⏳ Waiting for GPS data..."));

  // NRF24L01 init
  if (!radio.begin()) {
    Serial.println(F("❌ NRF24L01 not responding. Check wiring!"));
    while (1); // Stop everything
  }

  radio.setPALevel(RF24_PA_LOW);
  radio.setDataRate(RF24_250KBPS); // More stable at range
  radio.openWritingPipe(receiverAddress);
  radio.stopListening(); // TX mode
}

void loop() {
  // Feed GPS data to parser
  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }

  // Send data at fixed interval
  if (millis() - lastUpdate >= updateInterval) {
    lastUpdate = millis();

    Serial.println(F("========= GPS STATUS ========="));

    if (gps.location.isValid()) {
      float lat = gps.location.lat();
      float lng = gps.location.lng();

      Serial.print(F("📍 Location: "));
      Serial.print(lat, 6);
      Serial.print(F(", "));
      Serial.println(lng, 6);

      // Format data string
      char message[50];
      snprintf(message, sizeof(message), "%.6f,%.6f", lat, lng);

      // Transmit coordinates
      if (radio.write(&message, sizeof(message))) {
        Serial.print(F("📡 Sent: "));
        Serial.println(message);
      } else {
        Serial.println(F("❌ Failed to send via NRF24L01"));
      }
    } else {
      Serial.println(F("📍 Location: No fix yet."));
    }

    // Satellites info
    if (gps.satellites.isValid()) {
      Serial.print(F("🛰️  Satellites: "));
      Serial.println(gps.satellites.value());
    }

    Serial.println(F("================================\n"));
  }
}

