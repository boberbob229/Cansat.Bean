#include <SPI.h>
#include <RF24.h>
#include <SoftwareSerial.h>
#include <TinyGPS++.h>

// NRF24L01 setup
RF24 radio(7, 8); // CE, CSN
const byte address[6] = "05050";

// GPS setup
#define GPS_RX 4 // GPS TX -> Arduino RX
#define GPS_TX 3 // GPS RX <- Arduino TX (via voltage divider)
SoftwareSerial gpsSerial(GPS_RX, GPS_TX);
TinyGPSPlus gps;

// Data structure for sending via NRF24L01
struct Payload {
  float latitude;
  float longitude;
  char message[32];
};

Payload dataToSend;

unsigned long lastUpdate = 0;
const unsigned long updateInterval = 2000;

void setup() {
  Serial.begin(9600);
  gpsSerial.begin(9600);

  Serial.println("🔧 Starting GPS + Transmitter...");

  // Initialize NRF24L01
  if (!radio.begin()) {
    Serial.println("❌ NRF24L01 not responding. Check wiring and power!");
    while (1); // Stop everything if NRF fails
  }

  radio.setPALevel(RF24_PA_LOW);
  radio.setDataRate(RF24_250KBPS);
  radio.setChannel(108);
  radio.openWritingPipe(address);
  radio.stopListening(); // TX mode

  Serial.println("✅ NRF24L01 initialized. Sending GPS data...");
}

void loop() {
  // Read and parse GPS data
  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }

  // Update parsed GPS data every interval
  if (millis() - lastUpdate >= updateInterval) {
    lastUpdate = millis();

    Serial.println(F("========= GPS STATUS ========="));

    if (gps.location.isValid()) {
      dataToSend.latitude = gps.location.lat();
      dataToSend.longitude = gps.location.lng();

      Serial.print(F("📍 Location: "));
      Serial.print(dataToSend.latitude, 6);
      Serial.print(F(", "));
      Serial.println(dataToSend.longitude, 6);

      // Add a message
      strcpy(dataToSend.message, "Ping from TX!");

      // Send GPS data via NRF24L01
      Serial.println("📡 Sending GPS data...");
      bool sent = radio.write(&dataToSend, sizeof(dataToSend));

      if (sent) {
        Serial.println("✅ Data sent successfully!");
      } else {
        Serial.println("❌ Failed to send data.");
      }
    } else {
      Serial.println(F("📍 Location: No fix yet."));
    }

    // Satellites info
    if (gps.satellites.isValid()) {
      Serial.print(F("🛰️  Satellites: "));
      Serial.println(gps.satellites.value());
    } else {
      Serial.println(F("🛰️  Satellites: Unknown"));
    }

    // Date and time
    if (gps.date.isValid()) {
      Serial.print(F("📅 Date: "));
      Serial.print(gps.date.year());
      Serial.print("-");
      printDigits(gps.date.month());
      Serial.print("-");
      printDigits(gps.date.day());
      Serial.println();
    } else {
      Serial.println(F("📅 Date: Invalid"));
    }

    if (gps.time.isValid()) {
      Serial.print(F("⏰ Time (UTC): "));
      printDigits(gps.time.hour());
      Serial.print(":");
      printDigits(gps.time.minute());
      Serial.print(":");
      printDigits(gps.time.second());
      Serial.println();
    } else {
      Serial.println(F("⏰ Time: Invalid"));
    }

    Serial.println(F("================================\n"));
  }
}

// Helper: Pad numbers with leading 0
void printDigits(int digits) {
  if (digits < 10) Serial.print('0');
  Serial.print(digits);
}

